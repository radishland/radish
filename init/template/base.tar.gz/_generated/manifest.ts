import type { Manifest } from "../../../../src/generate/manifest.ts";

export const manifest = {} as Manifest;
