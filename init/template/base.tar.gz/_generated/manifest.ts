import type { Manifest } from "$core/src/generate/manifest.ts";

export const manifest = {} as Manifest;
